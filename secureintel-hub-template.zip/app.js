// NTRO SecureIntel Hub Application
class SecureIntelHub {
    constructor() {
        this.currentUser = 'analyst.sharma';
        this.currentSection = 'dashboard';
        this.scanInProgress = false;
        this.scanProgress = 0;
        this.scanPhase = 'idle';
        this.vulnerabilities = [];
        this.scanResults = null;
        this.charts = {};
        
        // RAG Bot properties
        this.ragBot = {
            name: 'ARIA',
            fullName: 'Advanced Risk Intelligence Assistant',
            role: 'Senior Cybersecurity Analyst',
            expertise: ['Vulnerability Assessment', 'Threat Intelligence', 'Incident Response', 'Risk Analysis']
        };
        this.conversations = [];
        this.currentConversation = [];
        this.isTyping = false;
        this.chatWidgetVisible = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupMockData();
        this.updateDashboard();
        this.generateReports();
        
        // Update timestamps periodically
        setInterval(() => this.updateTimestamps(), 30000);
    }
    
    setupEventListeners() {
        // Login form
        document.getElementById('login-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });
        
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                this.navigateTo(section);
            });
        });
        
        // Quick scan buttons
        document.querySelectorAll('.scan-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const scanType = btn.dataset.scanType;
                this.startQuickScan(scanType);
            });
        });
        
        // Scanner controls
        document.getElementById('start-scan')?.addEventListener('click', () => {
            this.startCustomScan();
        });
        
        document.getElementById('stop-scan')?.addEventListener('click', () => {
            this.stopScan();
        });
        
        // Query mode button
        document.getElementById('query-mode-btn')?.addEventListener('click', () => {
            this.navigateTo('query-interface');
        });
        
        // Query Interface event listeners
        document.getElementById('execute-query-btn')?.addEventListener('click', () => {
            this.executeNaturalLanguageQuery();
        });
        
        document.getElementById('main-query-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.executeNaturalLanguageQuery();
            }
        });
        
        // Example query buttons
        document.querySelectorAll('.example-query-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const query = btn.dataset.query;
                document.getElementById('main-query-input').value = query;
                this.executeNaturalLanguageQuery();
            });
        });
        
        // Export buttons
        document.getElementById('export-pdf')?.addEventListener('click', () => {
            this.exportResults('pdf');
        });
        
        document.getElementById('export-json')?.addEventListener('click', () => {
            this.exportResults('json');
        });
        
        // Vulnerability filters
        document.getElementById('severity-filter')?.addEventListener('change', (e) => {
            this.filterVulnerabilities(e.target.value);
        });
        
        document.getElementById('vuln-search')?.addEventListener('input', (e) => {
            this.searchVulnerabilities(e.target.value);
        });
        
        // Logout
        document.getElementById('logout-btn')?.addEventListener('click', () => {
            this.logout();
        });
        
        // Generate report
        document.getElementById('generate-report')?.addEventListener('click', () => {
            this.generateNewReport();
        });
        
        // Re-add example query buttons event listeners (for dynamically added elements)
        this.setupExampleQueryListeners();
        
        // RAG Bot event listeners
        document.getElementById('toggle-chat')?.addEventListener('click', () => {
            this.toggleChatWidget();
        });
        
        document.getElementById('close-chat')?.addEventListener('click', () => {
            this.toggleChatWidget();
        });
        
        document.getElementById('send-chat')?.addEventListener('click', () => {
            this.sendChatMessage();
        });
        
        document.getElementById('chat-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendChatMessage();
            }
        });
        
        document.getElementById('rag-send-btn')?.addEventListener('click', () => {
            this.sendRagMessage();
        });
        
        document.getElementById('rag-main-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendRagMessage();
            }
        });
        
        // Quick query buttons
        document.querySelectorAll('.quick-query-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const query = btn.dataset.query;
                this.sendQuickQuery(query, 'widget');
            });
        });
        
        document.querySelectorAll('.rag-action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const query = btn.dataset.query;
                this.sendQuickQuery(query, 'main');
            });
        });
        
        // Export conversation
        document.getElementById('export-conversation')?.addEventListener('click', () => {
            this.exportConversation();
        });
        
        document.getElementById('rag-generate-report')?.addEventListener('click', () => {
            this.generateRagReport();
        });
    }
    
    setupExampleQueryListeners() {
        // Re-setup example query buttons after DOM updates
        document.querySelectorAll('.example-query-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const query = btn.dataset.query;
                const queryInput = document.getElementById('main-query-input');
                if (queryInput) {
                    queryInput.value = query;
                    this.executeNaturalLanguageQuery();
                }
            });
        });
    }
    
    setupMockData() {
        this.vulnerabilities = [
            {
                cve: 'CVE-2024-1086',
                severity: 'critical',
                cvss: 9.8,
                title: 'Linux Kernel Privilege Escalation',
                description: 'Use-after-free vulnerability in netfilter',
                affected: ['Linux 5.14-6.6'],
                discovered: new Date(Date.now() - 86400000 * 2)
            },
            {
                cve: 'CVE-2024-0519',
                severity: 'high',
                cvss: 8.1,
                title: 'Apache HTTP Server Request Smuggling',
                description: 'HTTP request smuggling via malformed headers',
                affected: ['Apache 2.4.0-2.4.58'],
                discovered: new Date(Date.now() - 86400000 * 1)
            },
            {
                cve: 'CVE-2023-4863',
                severity: 'high',
                cvss: 8.8,
                title: 'Chrome WebP Buffer Overflow',
                description: 'Heap buffer overflow in WebP image processing',
                affected: ['Chrome < 116.0.5845.187'],
                discovered: new Date(Date.now() - 86400000 * 5)
            },
            {
                cve: 'CVE-2024-2567',
                severity: 'medium',
                cvss: 6.5,
                title: 'OpenSSL Certificate Validation Bypass',
                description: 'Improper certificate chain validation',
                affected: ['OpenSSL 3.0.0-3.0.8'],
                discovered: new Date(Date.now() - 86400000 * 3)
            },
            {
                cve: 'CVE-2024-1234',
                severity: 'medium',
                cvss: 5.7,
                title: 'WordPress Plugin SQL Injection',
                description: 'SQL injection in user input validation',
                affected: ['WordPress Plugin XYZ < 2.1.4'],
                discovered: new Date(Date.now() - 86400000 * 7)
            },
            {
                cve: 'CVE-2024-0987',
                severity: 'low',
                cvss: 3.1,
                title: 'Information Disclosure in Debug Logs',
                description: 'Sensitive information exposed in debug output',
                affected: ['Application Server v1.2.3'],
                discovered: new Date(Date.now() - 86400000 * 4)
            }
        ];
        
        this.threatFeeds = [
            { source: 'CERT-In', lastUpdate: '2 hours ago', alerts: 12, status: 'active' },
            { source: 'US-CERT', lastUpdate: '4 hours ago', alerts: 8, status: 'active' },
            { source: 'MITRE ATT&CK', lastUpdate: '1 day ago', alerts: 24, status: 'active' },
            { source: 'NIST NVD', lastUpdate: '6 hours ago', alerts: 16, status: 'active' }
        ];
        
        this.recentActivity = [
            { type: 'scan', message: 'Network scan completed for 192.168.1.0/24', time: '5 min ago', icon: 'fas fa-search' },
            { type: 'alert', message: 'Critical vulnerability detected in Apache server', time: '12 min ago', icon: 'fas fa-exclamation-triangle' },
            { type: 'update', message: 'Threat intelligence feeds updated', time: '23 min ago', icon: 'fas fa-sync' },
            { type: 'scan', message: 'Web application scan initiated', time: '35 min ago', icon: 'fas fa-globe' },
            { type: 'report', message: 'Security report generated for Q4 2024', time: '1 hour ago', icon: 'fas fa-file-alt' }
        ];
    }
    
    handleLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        if (!username || !password) {
            this.showNotification('Please enter both username and password', 'error');
            return;
        }
        
        // Show loading
        this.showLoading(true);
        
        // Simulate authentication delay
        setTimeout(() => {
            this.showLoading(false);
            
            // Simple mock authentication
            if (username && password) {
                this.currentUser = username;
                document.getElementById('current-user').textContent = username;
                document.getElementById('login-page').classList.remove('active');
                document.getElementById('main-app').classList.add('active');
                this.showNotification('Login successful', 'success');
            } else {
                this.showNotification('Invalid credentials', 'error');
            }
        }, 1500);
    }
    
    logout() {
        this.showLoading(true);
        
        setTimeout(() => {
            this.showLoading(false);
            document.getElementById('main-app').classList.remove('active');
            document.getElementById('login-page').classList.add('active');
            
            // Clear form
            document.getElementById('username').value = '';
            document.getElementById('password').value = '';
            
            this.showNotification('Logged out successfully', 'success');
        }, 1000);
    }
    
    navigateTo(section) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');
        
        // Update content sections
        document.querySelectorAll('.content-section').forEach(sec => {
            sec.classList.remove('active');
        });
        document.getElementById(section).classList.add('active');
        
        this.currentSection = section;
        
        // Initialize section-specific content
        if (section === 'results' && this.scanResults) {
            this.displayResults();
        } else if (section === 'results' && !this.scanResults) {
            this.generateMockResults();
            this.displayResults();
        } else if (section === 'rag-bot') {
            this.initializeRagBot();
        } else if (section === 'query-interface') {
            this.initializeQueryInterface();
        }
    }
    
    initializeRagBot() {
        // Initialize conversation if empty
        if (this.currentConversation.length === 0) {
            this.currentConversation.push({
                message: 'Session started',
                sender: 'system',
                timestamp: new Date(),
                container: 'main'
            });
        }
        
        // Update conversation history
        this.updateConversationHistory();
    }
    
    initializeQueryInterface() {
        // Reset query interface state
        const queryInput = document.getElementById('main-query-input');
        if (queryInput) {
            queryInput.value = '';
            queryInput.focus();
        }
        
        // Hide progress dashboard
        document.getElementById('scan-progress-dashboard')?.classList.add('hidden');
        
        // Add SVG gradient definition for progress ring
        this.addProgressGradient();
    }
    
    addProgressGradient() {
        // Add SVG gradient for circular progress if it doesn't exist
        if (document.getElementById('progressGradient')) return;
        
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.style.position = 'absolute';
        svg.style.width = '0';
        svg.style.height = '0';
        
        const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        const gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
        gradient.id = 'progressGradient';
        gradient.setAttribute('x1', '0%');
        gradient.setAttribute('y1', '0%');
        gradient.setAttribute('x2', '100%');
        gradient.setAttribute('y2', '0%');
        
        const stop1 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
        stop1.setAttribute('offset', '0%');
        stop1.setAttribute('stop-color', '#3498db');
        
        const stop2 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
        stop2.setAttribute('offset', '100%');
        stop2.setAttribute('stop-color', '#2ecc71');
        
        gradient.appendChild(stop1);
        gradient.appendChild(stop2);
        defs.appendChild(gradient);
        svg.appendChild(defs);
        
        document.body.appendChild(svg);
    }
    
    updateConversationHistory() {
        const historyEl = document.getElementById('conversation-history');
        if (!historyEl) return;
        
        const sessionCount = Math.floor(this.currentConversation.length / 10) + 1;
        const currentTime = new Date().toLocaleString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            timeZone: 'Asia/Kolkata'
        });
        
        historyEl.innerHTML = `
            <div class="history-item active">
                <div class="history-title">Current Session #${sessionCount}</div>
                <div class="history-time">Started at ${currentTime}</div>
            </div>
            <div class="history-item">
                <div class="history-title">Previous Session</div>
                <div class="history-time">2 hours ago</div>
            </div>
            <div class="history-item">
                <div class="history-title">Vulnerability Analysis</div>
                <div class="history-time">Yesterday</div>
            </div>
        `;
    }
    
    updateDashboard() {
        // Update timestamp
        const now = new Date();
        const timestamp = now.toLocaleString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            timeZone: 'Asia/Kolkata'
        });
        
        const timestampEl = document.getElementById('dashboard-timestamp');
        if (timestampEl) {
            timestampEl.textContent = timestamp;
        }
        
        // Update activity feed
        this.updateActivityFeed();
        
        // Update threat intelligence feeds
        this.updateThreatFeeds();
    }
    
    updateActivityFeed() {
        const feedEl = document.getElementById('activity-feed');
        if (!feedEl) return;
        
        feedEl.innerHTML = this.recentActivity.map(activity => `
            <div class="activity-item">
                <i class="${activity.icon}"></i>
                <span>${activity.message}</span>
                <span class="time">${activity.time}</span>
            </div>
        `).join('');
    }
    
    updateThreatFeeds() {
        const feedsEl = document.getElementById('threat-feeds');
        if (!feedsEl) return;
        
        feedsEl.innerHTML = this.threatFeeds.map(feed => `
            <div class="feed-item">
                <div class="status-indicator ${feed.status}"></div>
                <div>
                    <strong>${feed.source}</strong>
                    <br>
                    <small>${feed.alerts} new alerts</small>
                </div>
                <span class="time">${feed.lastUpdate}</span>
            </div>
        `).join('');
    }
    
    startQuickScan(scanType) {
        this.navigateTo('scanner');
        
        // Pre-fill scan target based on type
        const targetInput = document.getElementById('scan-target');
        if (targetInput) {
            switch (scanType) {
                case 'network':
                    targetInput.value = '192.168.1.0/24';
                    break;
                case 'webapp':
                    targetInput.value = 'https://testapp.example.com';
                    break;
                case 'infrastructure':
                    targetInput.value = '10.0.0.0/16';
                    break;
            }
        }
        
        // Auto-start scan after a brief delay
        setTimeout(() => {
            this.startCustomScan();
        }, 500);
    }
    
    startCustomScan() {
        if (this.scanInProgress) {
            this.showModernNotification('Scan already in progress', 'warning', 'Scan Status');
            return;
        }
        
        const target = document.getElementById('scan-target').value;
        if (!target) {
            this.showModernNotification('Please enter a target to begin scanning', 'error', 'Target Required');
            return;
        }
        
        this.scanInProgress = true;
        this.scanProgress = 0;
        this.scanPhase = 'discovery';
        
        // Update UI
        document.getElementById('start-scan').disabled = true;
        document.getElementById('stop-scan').disabled = false;
        document.getElementById('scan-progress').classList.remove('hidden');
        
        // Start modern scan simulation
        this.simulateModernScan(target);
        
        this.showModernNotification(
            `Advanced security analysis initiated for ${target}. Real-time threat intelligence correlation enabled.`, 
            'success', 
            'Scan Started'
        );
        
        // Add modern log messages
        this.addLogMessage('Advanced threat analysis pipeline activated', 'success');
        this.addLogMessage('Real-time vulnerability correlation enabled', 'info');
    }
    
    simulateModernScan(target) {
        const phases = [
            {
                name: 'Initialization',
                duration: 2000,
                description: 'Preparing advanced scan environment',
                activities: [
                    'Initializing threat intelligence feeds',
                    'Loading vulnerability signatures',
                    'Configuring scan parameters'
                ]
            },
            {
                name: 'Discovery', 
                duration: 8000,
                description: 'AI-powered network asset discovery',
                activities: [
                    'Intelligent host discovery in progress',
                    'Advanced port scanning with stealth techniques',
                    'Service fingerprinting and enumeration',
                    'Network topology mapping'
                ]
            },
            {
                name: 'Assessment',
                duration: 25000,
                description: 'Comprehensive vulnerability assessment',
                activities: [
                    'Deep vulnerability scanning initiated',
                    'Correlating findings with threat intelligence',
                    'Advanced exploit verification',
                    'Risk scoring with AI algorithms',
                    'Configuration compliance checking'
                ]
            },
            {
                name: 'Analysis',
                duration: 10000,
                description: 'AI-enhanced threat analysis',
                activities: [
                    'Advanced pattern recognition analysis',
                    'Attack path modeling in progress',
                    'Threat actor correlation',
                    'Risk prioritization algorithms'
                ]
            },
            {
                name: 'Correlation',
                duration: 5000,
                description: 'Global threat intelligence correlation',
                activities: [
                    'Cross-referencing with global threat feeds',
                    'APT campaign correlation',
                    'Vulnerability lifecycle analysis'
                ]
            },
            {
                name: 'Reporting',
                duration: 3000,
                description: 'Generating comprehensive analysis',
                activities: [
                    'Compiling executive summary',
                    'Generating technical recommendations',
                    'Creating attack path visualizations'
                ]
            }
        ];
        
        let currentPhaseIndex = 0;
        let totalProgress = 0;
        const totalDuration = phases.reduce((sum, phase) => sum + phase.duration, 0);
        
        const executePhase = (phaseIndex) => {
            if (phaseIndex >= phases.length) {
                this.completeModernScan(target);
                return;
            }
            
            const phase = phases[phaseIndex];
            this.updateScanPhase(phase.name, phase.description);
            
            let phaseProgress = 0;
            let activityIndex = 0;
            
            const phaseInterval = setInterval(() => {
                if (!this.scanInProgress) {
                    clearInterval(phaseInterval);
                    return;
                }
                
                phaseProgress += Math.random() * 3 + 1;
                totalProgress = ((phaseIndex * 100 + phaseProgress) / phases.length);
                
                this.updateScanProgress(Math.min(totalProgress, 100));
                
                // Add phase activities
                if (Math.random() < 0.3 && activityIndex < phase.activities.length) {
                    this.addLogMessage(phase.activities[activityIndex], 'info');
                    activityIndex++;
                }
                
                if (phaseProgress >= 100) {
                    clearInterval(phaseInterval);
                    this.completePhase(phase.name);
                    setTimeout(() => executePhase(phaseIndex + 1), 500);
                }
            }, 200);
        };
        
        executePhase(0);
    }
    
    updateScanPhase(phaseName, description) {
        // Update phase indicators
        document.querySelectorAll('.phase').forEach(p => p.classList.remove('active'));
        const phaseEl = document.getElementById(`phase-${phaseName.toLowerCase()}`);
        if (phaseEl) {
            phaseEl.classList.add('active');
        }
        
        // Update scan phase description
        this.scanPhase = phaseName.toLowerCase();
    }
    
    updateScanProgress(percentage) {
        this.scanProgress = percentage;
        
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        if (progressFill) progressFill.style.width = `${percentage}%`;
        if (progressText) progressText.textContent = `${Math.round(percentage)}%`;
    }
    
    completePhase(phaseName) {
        const phaseEl = document.getElementById(`phase-${phaseName.toLowerCase()}`);
        if (phaseEl) {
            phaseEl.classList.remove('active');
            phaseEl.classList.add('completed');
        }
        
        this.addLogMessage(`${phaseName} phase completed successfully`, 'success');
    }
    
    completeModernScan(target) {
        this.scanInProgress = false;
        
        // Update final phase
        document.querySelectorAll('.phase').forEach(p => {
            p.classList.remove('active');
            p.classList.add('completed');
        });
        
        // Update UI
        document.getElementById('start-scan').disabled = false;
        document.getElementById('stop-scan').disabled = true;
        
        this.addLogMessage('Advanced security analysis completed successfully!', 'success');
        this.addLogMessage(`Comprehensive assessment of ${target} finished`, 'success');
        this.addLogMessage(`Found ${this.vulnerabilities.length} security findings with threat intelligence correlation`, 'info');
        this.addLogMessage('Detailed results available in Results section', 'info');
        
        // Generate enhanced scan results
        this.generateEnhancedScanResults(target);
        
        this.showModernNotification(
            `Advanced security analysis of ${target} completed! Threat intelligence correlation applied to ${this.vulnerabilities.length} findings.`,
            'success',
            'Analysis Complete'
        );
        
        // Update activity feed with modern entry
        this.recentActivity.unshift({
            type: 'scan',
            message: `Advanced AI-enhanced security analysis completed for ${target} - ${this.vulnerabilities.length} findings with threat correlation`,
            time: 'just now',
            icon: 'fas fa-shield-alt'
        });
        
        if (this.recentActivity.length > 10) this.recentActivity.pop();
        this.updateActivityFeed();
    }
    
    generateEnhancedScanResults(target) {
        this.scanResults = {
            target: target,
            timestamp: new Date(),
            scanType: 'AI-Enhanced Security Analysis',
            threatIntelligence: true,
            vulnerabilities: [...this.vulnerabilities],
            summary: {
                critical: this.vulnerabilities.filter(v => v.severity === 'critical').length,
                high: this.vulnerabilities.filter(v => v.severity === 'high').length,
                medium: this.vulnerabilities.filter(v => v.severity === 'medium').length,
                low: this.vulnerabilities.filter(v => v.severity === 'low').length
            },
            threatCorrelation: {
                aptCampaigns: Math.floor(Math.random() * 5) + 2,
                activeThreats: Math.floor(Math.random() * 8) + 3,
                globalCorrelations: Math.floor(Math.random() * 15) + 10
            }
        };
    }
    
    simulateScan() {
        const phases = ['discovery', 'scanning', 'analysis', 'reporting'];
        let currentPhaseIndex = 0;
        const totalDuration = 25000; // 25 seconds
        const updateInterval = 500; // Update every 500ms
        const totalUpdates = totalDuration / updateInterval;
        let currentUpdate = 0;
        
        const logMessages = {
            discovery: [
                'Starting host discovery...',
                'Pinging target range...',
                'Found 12 active hosts',
                'Performing reverse DNS lookup...',
                'Discovery phase completed'
            ],
            scanning: [
                'Starting port scans...',
                'Scanning common ports...',
                'Found open ports: 22, 80, 443, 3306',
                'Running service detection...',
                'Identified: SSH, Apache, MySQL',
                'Performing vulnerability scans...',
                'OpenVAS scan in progress...',
                'Nuclei templates executing...'
            ],
            analysis: [
                'Analyzing scan results...',
                'Cross-referencing with threat intelligence...',
                'Calculating risk scores...',
                'Identifying attack paths...',
                'Generating vulnerability database matches',
                'Analysis complete'
            ],
            reporting: [
                'Compiling final report...',
                'Generating charts and graphs...',
                'Preparing recommendations...',
                'Scan completed successfully'
            ]
        };
        
        const interval = setInterval(() => {
            if (!this.scanInProgress) {
                clearInterval(interval);
                return;
            }
            
            currentUpdate++;
            this.scanProgress = Math.min((currentUpdate / totalUpdates) * 100, 100);
            
            // Update progress bar
            const progressFill = document.getElementById('progress-fill');
            const progressText = document.getElementById('progress-text');
            
            if (progressFill) progressFill.style.width = `${this.scanProgress}%`;
            if (progressText) progressText.textContent = `${Math.round(this.scanProgress)}%`;
            
            // Update phase
            const phaseProgress = currentUpdate / (totalUpdates / phases.length);
            const newPhaseIndex = Math.min(Math.floor(phaseProgress), phases.length - 1);
            
            if (newPhaseIndex !== currentPhaseIndex) {
                // Update previous phase to completed
                if (currentPhaseIndex >= 0) {
                    document.getElementById(`phase-${phases[currentPhaseIndex]}`)?.classList.add('completed');
                    document.getElementById(`phase-${phases[currentPhaseIndex]}`)?.classList.remove('active');
                }
                currentPhaseIndex = newPhaseIndex;
            }
            
            // Update current phase
            document.querySelectorAll('.phase').forEach(p => p.classList.remove('active'));
            document.getElementById(`phase-${phases[currentPhaseIndex]}`)?.classList.add('active');
            
            // Add log messages
            if (Math.random() < 0.3 && logMessages[phases[currentPhaseIndex]]?.length > 0) {
                const message = logMessages[phases[currentPhaseIndex]].shift();
                this.addLogMessage(message, 'info');
            }
            
            // Complete scan
            if (this.scanProgress >= 100) {
                clearInterval(interval);
                this.completeScan();
            }
        }, updateInterval);
    }
    
    addLogMessage(message, type = 'info') {
        const logEl = document.getElementById('scan-log');
        if (!logEl) return;
        
        const timestamp = new Date().toLocaleTimeString('en-IN', {
            hour12: false,
            timeZone: 'Asia/Kolkata'
        });
        
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry';
        logEntry.innerHTML = `
            <span class="log-timestamp">[${timestamp}]</span> 
            <span class="log-${type}">[MCP] ${message}</span>
        `;
        
        logEl.appendChild(logEntry);
        logEl.scrollTop = logEl.scrollHeight;
        
        // Keep only last 50 messages
        while (logEl.children.length > 50) {
            logEl.removeChild(logEl.firstChild);
        }
    }
    
    completeScan() {
        this.scanInProgress = false;
        
        // Update final phase
        document.getElementById('phase-reporting')?.classList.add('completed');
        document.getElementById('phase-reporting')?.classList.remove('active');
        
        // Update UI
        document.getElementById('start-scan').disabled = false;
        document.getElementById('stop-scan').disabled = true;
        
        this.addLogMessage('Scan completed successfully!', 'success');
        this.addLogMessage(`Found ${this.vulnerabilities.length} vulnerabilities`, 'info');
        this.addLogMessage('Results available in Results section', 'info');
        
        // Generate scan results
        this.generateScanResults();
        
        this.showNotification('Scan completed! Check results section.', 'success');
        
        // Update activity feed
        this.recentActivity.unshift({
            type: 'scan',
            message: `MCP-enhanced scan completed - ${this.vulnerabilities.length} vulnerabilities found with threat intelligence correlation`,
            time: 'just now',
            icon: 'fas fa-check-circle'
        });
        
        if (this.recentActivity.length > 10) this.recentActivity.pop();
        this.updateActivityFeed();
    }
    
    stopScan() {
        if (!this.scanInProgress) return;
        
        this.scanInProgress = false;
        
        // Update UI
        document.getElementById('start-scan').disabled = false;
        document.getElementById('stop-scan').disabled = true;
        document.getElementById('scan-progress').classList.add('hidden');
        
        // Reset progress
        document.getElementById('progress-fill').style.width = '0%';
        document.getElementById('progress-text').textContent = '0%';
        
        // Reset phases
        document.querySelectorAll('.phase').forEach(phase => {
            phase.classList.remove('active', 'completed');
        });
        
        this.addLogMessage('Scan stopped by user', 'warning');
        this.showNotification('Scan stopped', 'warning');
    }
    
    executeNaturalLanguageQuery() {
        const query = document.getElementById('main-query-input')?.value.trim();
        if (!query) {
            this.showModernNotification('Please enter a security query to begin analysis', 'warning', 'Query Required');
            return;
        }
        
        // Start the automated analysis workflow
        this.startMCPWorkflow(query);
        
        // Update activity feed
        this.recentActivity.unshift({
            type: 'scan',
            message: `AI processing natural language query: "${query.substring(0, 50)}${query.length > 50 ? '...' : ''}"`,
            time: 'just now',
            icon: 'fas fa-brain'
        });
        
        if (this.recentActivity.length > 10) this.recentActivity.pop();
        this.updateActivityFeed();
    }
    
    startMCPWorkflow(query) {
        this.showModernNotification('AI analyzing your security query...', 'info', 'Processing Query');
        
        // Show modern progress dashboard
        document.getElementById('scan-progress-dashboard')?.classList.remove('hidden');
        
        // Initialize scanner states
        this.initializeScannerStates();
        
        // Clear activity stream
        const streamEl = document.getElementById('activity-stream');
        if (streamEl) streamEl.innerHTML = '';
        
        // Start automated analysis
        this.startAutomatedAnalysis(query);
    }
    
    startAutomatedAnalysis(query) {
        // Initialize overall progress
        this.overallProgress = 0;
        this.scanStartTime = Date.now();
        
        // Set up scanners based on query
        const scanners = this.selectScannersForQuery(query);
        
        // Update UI
        this.updateCurrentPhase('AI analyzing query and selecting optimal scanners...');
        this.addActivityItem('Query received and processed', 'info');
        
        // Start scanner sequence
        setTimeout(() => {
            this.addActivityItem(`Selected ${scanners.length} scanners for analysis`, 'info');
            this.startScannerSequence(scanners);
        }, 1500);
    }
    
    selectScannersForQuery(query) {
        const lowerQuery = query.toLowerCase();
        const scanners = ['nmap']; // Always include network discovery
        
        if (lowerQuery.includes('web') || lowerQuery.includes('http') || lowerQuery.includes('application')) {
            scanners.push('nikto');
        }
        
        if (lowerQuery.includes('vulnerability') || lowerQuery.includes('critical') || lowerQuery.includes('security')) {
            scanners.push('openvas');
        }
        
        scanners.push('nuclei'); // Always include template-based scanning
        
        return scanners;
    }
    
    initializeScannerStates() {
        const scanners = ['nmap', 'openvas', 'nikto', 'nuclei'];
        
        scanners.forEach(scanner => {
            this.updateScannerStatus(scanner, 'queued');
            this.updateScannerProgress(scanner, 0);
            this.updateScannerFindings(scanner, 0);
            this.updateScannerTime(scanner, '--');
        });
        
        // Reset overall progress
        this.updateOverallProgress(0);
    }
    
    startScannerSequence(selectedScanners) {
        let currentScanner = 0;
        
        const startNextScanner = () => {
            if (currentScanner >= selectedScanners.length) {
                this.completeAutomatedAnalysis();
                return;
            }
            
            const scanner = selectedScanners[currentScanner];
            this.startScannerExecution(scanner, () => {
                currentScanner++;
                setTimeout(startNextScanner, 500);
            });
        };
        
        startNextScanner();
    }
    
    startScannerExecution(scanner, callback) {
        this.updateScannerStatus(scanner, 'active');
        this.addActivityItem(`Starting ${this.getScannerDisplayName(scanner)} scan`, 'info');
        
        const duration = this.getScannerDuration(scanner);
        const startTime = Date.now();
        
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 8 + 2; // Varied progress speed
            
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                
                this.updateScannerStatus(scanner, 'complete');
                this.updateScannerProgress(scanner, 100);
                
                const findings = this.generateScannerFindings(scanner);
                this.updateScannerFindings(scanner, findings);
                
                const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
                this.updateScannerTime(scanner, `${elapsed}s`);
                
                this.addActivityItem(`${this.getScannerDisplayName(scanner)} completed - ${findings} ${this.getFindingsLabel(scanner)} found`, 'success');
                
                // Update overall progress
                this.updateOverallProgressIncrement();
                
                callback();
            } else {
                this.updateScannerProgress(scanner, progress);
                
                const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
                this.updateScannerTime(scanner, `${elapsed}s`);
                
                // Occasional activity updates
                if (Math.random() < 0.15) {
                    this.addScannerActivity(scanner, progress);
                }
            }
        }, 200 + Math.random() * 300); // Varied update frequency
    }
    
    getScannerDisplayName(scanner) {
        const names = {
            'nmap': 'Network Discovery',
            'openvas': 'Vulnerability Assessment', 
            'nikto': 'Web Server Analysis',
            'nuclei': 'Template-based Scanning'
        };
        return names[scanner] || scanner;
    }
    
    getScannerDuration(scanner) {
        const durations = {
            'nmap': 8000,
            'openvas': 15000,
            'nikto': 12000,
            'nuclei': 10000
        };
        return durations[scanner] || 10000;
    }
    
    generateScannerFindings(scanner) {
        const ranges = {
            'nmap': [8, 25],
            'openvas': [15, 45],
            'nikto': [3, 12],
            'nuclei': [5, 18]
        };
        const range = ranges[scanner] || [1, 10];
        return Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
    }
    
    getFindingsLabel(scanner) {
        const labels = {
            'nmap': 'hosts',
            'openvas': 'vulnerabilities',
            'nikto': 'issues',
            'nuclei': 'matches'
        };
        return labels[scanner] || 'findings';
    }
    
    addScannerActivity(scanner, progress) {
        const activities = {
            'nmap': [
                'Discovering active hosts...',
                'Performing port scans...',
                'Detecting service versions...',
                'Analyzing network topology...'
            ],
            'openvas': [
                'Loading vulnerability database...',
                'Scanning for known vulnerabilities...',
                'Performing compliance checks...',
                'Analyzing security configurations...'
            ],
            'nikto': [
                'Testing web server configurations...',
                'Checking for dangerous files...',
                'Analyzing HTTP headers...',
                'Testing for common vulnerabilities...'
            ],
            'nuclei': [
                'Loading template database...',
                'Executing security templates...',
                'Checking for misconfigurations...',
                'Analyzing application security...'
            ]
        };
        
        const scannerActivities = activities[scanner] || ['Scanning...'];
        const activity = scannerActivities[Math.floor(Math.random() * scannerActivities.length)];
        
        this.addActivityItem(activity, 'info');
    }
    
    updateScannerStatus(scanner, status) {
        const statusDot = document.getElementById(`${scanner}-status`);
        const scannerCard = document.getElementById(`scanner-${scanner}`);
        
        if (statusDot) {
            statusDot.className = 'scanner-status-dot ' + status;
        }
        
        if (scannerCard) {
            scannerCard.className = 'scanner-card ' + status;
        }
    }
    
    updateScannerProgress(scanner, progress) {
        const progressEl = document.getElementById(`${scanner}-progress`);
        if (progressEl) {
            progressEl.style.width = `${progress}%`;
        }
    }
    
    updateScannerFindings(scanner, count) {
        const findingsEl = document.getElementById(`${scanner}-findings`);
        if (findingsEl) {
            const label = this.getFindingsLabel(scanner);
            findingsEl.textContent = `${count} ${label}`;
        }
    }
    
    updateScannerTime(scanner, time) {
        const timeEl = document.getElementById(`${scanner}-time`);
        if (timeEl) {
            timeEl.textContent = time;
        }
    }
    
    updateOverallProgress(percentage) {
        this.overallProgress = percentage;
        
        // Update circular progress
        const progressRing = document.getElementById('progress-ring');
        const percentageEl = document.getElementById('overall-percentage');
        
        if (progressRing) {
            const circumference = 2 * Math.PI * 50; // radius = 50
            const offset = circumference - (percentage / 100) * circumference;
            progressRing.style.strokeDashoffset = offset;
        }
        
        if (percentageEl) {
            percentageEl.textContent = `${Math.round(percentage)}%`;
        }
        
        // Update estimated time
        if (this.scanStartTime && percentage > 5) {
            const elapsed = (Date.now() - this.scanStartTime) / 1000;
            const estimated = (elapsed / percentage) * 100;
            const remaining = Math.max(0, estimated - elapsed);
            
            const estimatedEl = document.getElementById('estimated-time');
            if (estimatedEl && remaining > 0) {
                const minutes = Math.floor(remaining / 60);
                const seconds = Math.floor(remaining % 60);
                estimatedEl.textContent = `Estimated completion: ${minutes}m ${seconds}s`;
            } else if (estimatedEl) {
                estimatedEl.textContent = 'Finalizing analysis...';
            }
        }
    }
    
    updateOverallProgressIncrement() {
        const increment = 100 / 4; // 4 scanners
        this.updateOverallProgress(Math.min(this.overallProgress + increment, 100));
    }
    
    updateCurrentPhase(phase) {
        const phaseEl = document.getElementById('current-phase');
        if (phaseEl) {
            phaseEl.textContent = phase;
        }
    }
    
    addActivityItem(message, type) {
        const streamEl = document.getElementById('activity-stream');
        if (!streamEl) return;
        
        // Remove placeholder if exists
        const placeholder = streamEl.querySelector('.activity-placeholder');
        if (placeholder) {
            placeholder.remove();
        }
        
        const timestamp = new Date().toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            timeZone: 'Asia/Kolkata'
        });
        
        const activityEl = document.createElement('div');
        activityEl.className = 'activity-item';
        activityEl.innerHTML = `
            <div class="activity-icon ${type}">
                <i class="fas fa-${this.getActivityIcon(type)}"></i>
            </div>
            <span>${message}</span>
            <span class="activity-time">${timestamp}</span>
        `;
        
        streamEl.insertBefore(activityEl, streamEl.firstChild);
        
        // Keep only last 20 items
        while (streamEl.children.length > 20) {
            streamEl.removeChild(streamEl.lastChild);
        }
    }
    
    getActivityIcon(type) {
        const icons = {
            'info': 'info-circle',
            'success': 'check-circle',
            'warning': 'exclamation-triangle',
            'error': 'times-circle'
        };
        return icons[type] || 'info-circle';
    }
    
    completeAutomatedAnalysis() {
        this.updateOverallProgress(100);
        this.updateCurrentPhase('Analysis complete - processing results...');
        
        this.addActivityItem('All scanners completed successfully', 'success');
        this.addActivityItem('Generating comprehensive security report', 'info');
        
        setTimeout(() => {
            this.addActivityItem('Results available in Scan Results section', 'success');
            this.showModernNotification(
                'Security analysis completed! Advanced threat intelligence and vulnerability correlation applied.',
                'success',
                'Analysis Complete'
            );
            
            // Generate and navigate to results
            this.generateScanResults();
            
            setTimeout(() => {
                this.navigateTo('scanner');
                this.startCustomScan();
            }, 2000);
        }, 1500);
    }
    
    // This method is now replaced by addActivityItem
    
    // This method is now replaced by completeAutomatedAnalysis
    
    generateQueryBasedResults(query) {
        const lowerQuery = query.toLowerCase();
        
        // Adjust scan target based on query
        const targetInput = document.getElementById('scan-target');
        if (targetInput) {
            if (lowerQuery.includes('network') || lowerQuery.includes('infrastructure')) {
                targetInput.value = '192.168.1.0/24';
            } else if (lowerQuery.includes('web') || lowerQuery.includes('application')) {
                targetInput.value = 'https://webapp.company.local';
            } else {
                targetInput.value = 'Auto-detected targets';
            }
        }
        
        // Enable appropriate scanners based on query
        if (lowerQuery.includes('sql injection') || lowerQuery.includes('web')) {
            document.getElementById('nikto').checked = true;
        }
        if (lowerQuery.includes('privilege escalation') || lowerQuery.includes('critical')) {
            document.getElementById('openvas').checked = true;
            document.getElementById('nuclei').checked = true;
        }
    }
    
    toggleChatWidget() {
        const widget = document.getElementById('rag-chat-widget');
        if (!widget) return;
        
        this.chatWidgetVisible = !this.chatWidgetVisible;
        
        if (this.chatWidgetVisible) {
            widget.classList.remove('hidden');
        } else {
            widget.classList.add('hidden');
        }
    }
    
    sendChatMessage() {
        const input = document.getElementById('chat-input');
        if (!input) return;
        
        const message = input.value.trim();
        if (!message) return;
        
        this.addChatMessage(message, 'user', 'widget');
        input.value = '';
        
        this.processRagQuery(message, 'widget');
    }
    
    sendRagMessage() {
        const input = document.getElementById('rag-main-input');
        if (!input) return;
        
        const message = input.value.trim();
        if (!message) return;
        
        this.addChatMessage(message, 'user', 'main');
        input.value = '';
        
        this.processRagQuery(message, 'main');
    }
    
    sendQuickQuery(query, source) {
        if (!query) return;
        
        if (source === 'header') {
            // Show chat widget if not visible
            if (!this.chatWidgetVisible) {
                this.toggleChatWidget();
            }
            this.addChatMessage(query, 'user', 'widget');
            this.processRagQuery(query, 'widget');
        } else {
            this.addChatMessage(query, 'user', source);
            this.processRagQuery(query, source);
        }
    }
    
    addChatMessage(message, sender, container) {
        const messagesContainer = container === 'widget' ? 
            document.getElementById('chat-messages') : 
            document.getElementById('rag-main-messages');
        
        if (!messagesContainer) return;
        
        const messageEl = document.createElement('div');
        messageEl.className = `message ${sender}-message`;
        
        const time = new Date().toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            timeZone: 'Asia/Kolkata'
        });
        
        messageEl.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
            </div>
            <div class="message-content">
                <p>${this.formatMessage(message)}</p>
                <div class="message-time">${time}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageEl);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Add to conversation history
        this.currentConversation.push({
            message,
            sender,
            timestamp: new Date(),
            container
        });
    }
    
    formatMessage(message) {
        // Handle line breaks and basic formatting
        return message
            .replace(/\n\n/g, '</p><p>')
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
    }
    
    showTypingIndicator(container) {
        const messagesContainer = container === 'widget' ? 
            document.getElementById('chat-messages') : 
            document.getElementById('rag-main-messages');
        
        if (!messagesContainer) return;
        
        const typingEl = document.createElement('div');
        typingEl.className = 'message bot-message typing-indicator';
        typingEl.id = `typing-${container}`;
        typingEl.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="typing-indicator">
                    <span>ARIA is typing</span>
                    <div class="typing-dots">
                        <div class="typing-dot"></div>
                        <div class="typing-dot"></div>
                        <div class="typing-dot"></div>
                    </div>
                </div>
            </div>
        `;
        
        messagesContainer.appendChild(typingEl);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    hideTypingIndicator(container) {
        const typingEl = document.getElementById(`typing-${container}`);
        if (typingEl) {
            typingEl.remove();
        }
    }
    
    processRagQuery(query, container) {
        this.isTyping = true;
        this.showTypingIndicator(container);
        
        // Simulate realistic response time
        const responseTime = 1500 + Math.random() * 2000;
        
        setTimeout(() => {
            this.hideTypingIndicator(container);
            const response = this.generateRagResponse(query);
            this.addChatMessage(response, 'bot', container);
            this.isTyping = false;
        }, responseTime);
    }
    
    generateRagResponse(query) {
        const lowerQuery = query.toLowerCase();
        
        // Handle MCP-related queries
        if (lowerQuery.includes('mcp') || lowerQuery.includes('pipeline')) {
            return `**MCP Pipeline Status:**\n\n**Current State:** Operational and processing security data\n\n**Pipeline Components:**\n- **Data Ingestion:** Processing 2.3k events/sec\n- **Parsing & Enrichment:** 1.8k events/sec\n- **Threat Analysis:** 1.2k events/sec\n- **Visualization:** 800 events/sec\n\n**Recent Activity:**\n- Natural language query processing active\n- Threat intelligence correlation running\n- Vulnerability data enrichment in progress\n\n**Health Status:** All components healthy\n**Queue Depth:** 142 items\n**Average Latency:** 45ms\n\nThe MCP pipeline is designed to automatically trigger appropriate scanners based on natural language queries and enrich the results with threat intelligence for comprehensive security analysis.`;
        }
        
        // Predefined responses for specific queries
        const sampleResponses = {
            'analyze critical vulnerabilities': {
                response: "Based on the latest scan, I've identified 3 critical vulnerabilities requiring immediate attention:\n\n1. **CVE-2024-1086** (CVSS 9.8) - Linux Kernel Privilege Escalation\n   - Affects 12 systems in your network\n   - Exploitation difficulty: Low\n   - **Recommendation**: Apply kernel patches immediately\n\n2. **CVE-2024-0519** (CVSS 8.1) - Apache HTTP Server Request Smuggling\n   - Affects web servers on ports 80, 443\n   - Active exploitation detected in the wild\n   - **Recommendation**: Update Apache to 2.4.59+\n\nShall I provide detailed mitigation steps for any of these?"
            },
            'analyze the critical vulnerabilities found in the last scan': {
                response: "Based on the latest scan, I've identified 3 critical vulnerabilities requiring immediate attention:\n\n1. **CVE-2024-1086** (CVSS 9.8) - Linux Kernel Privilege Escalation\n   - Affects 12 systems in your network\n   - Exploitation difficulty: Low\n   - **Recommendation**: Apply kernel patches immediately\n\n2. **CVE-2024-0519** (CVSS 8.1) - Apache HTTP Server Request Smugging\n   - Affects web servers on ports 80, 443\n   - Active exploitation detected in the wild\n   - **Recommendation**: Update Apache to 2.4.59+\n\nShall I provide detailed mitigation steps for any of these?"
            },
            "what's the attack path for cve-2024-1086?": {
                response: "**Attack Path Analysis for CVE-2024-1086:**\n\n**Initial Access**: Attacker gains low-privilege user access\n↓\n**Privilege Escalation**: Exploits netfilter use-after-free vulnerability\n↓\n**System Compromise**: Gains root/administrator privileges\n↓\n**Lateral Movement**: Uses elevated access to compromise other systems\n\nThis vulnerability has a **96% success rate** in lab environments and is being actively exploited by APT groups.\n\n**Immediate Actions Required:**\n- Isolate affected Linux systems\n- Monitor for suspicious privilege escalation\n- Deploy emergency patches within 24 hours"
            },
            'recommend mitigation strategies for apache vulnerabilities': {
                response: "**Apache Vulnerability Mitigation Strategies:**\n\n**Immediate Actions (0-24 hours):**\n1. Update Apache to version 2.4.59 or later\n2. Enable ModSecurity with OWASP Core Rule Set\n3. Configure request size limits\n4. Disable unnecessary modules\n\n**Short-term Actions (1-7 days):**\n1. Implement Web Application Firewall (WAF)\n2. Enable comprehensive logging\n3. Set up intrusion detection systems\n4. Configure fail2ban for brute force protection\n\n**Long-term Actions (1-4 weeks):**\n1. Regular security audits and penetration testing\n2. Automated vulnerability scanning\n3. Security awareness training for developers\n4. Implement CI/CD security checks\n\nWould you like detailed configuration steps for any of these measures?"
            },
            'compare current threats with historical patterns': {
                response: "**Threat Pattern Analysis:**\n\n**Current Month vs Previous Quarter:**\n- Critical vulnerabilities: ↑ 23% increase\n- Web application attacks: ↑ 45% increase\n- Privilege escalation attempts: ↑ 67% increase\n\n**Notable Trends:**\n1. **Linux kernel exploits** are dominating the landscape\n2. **Supply chain attacks** have increased 3x\n3. **AI-powered attacks** are emerging\n\n**Threat Actor Activity:**\n- **APT28**: Increased focus on infrastructure targets\n- **Lazarus Group**: Targeting financial institutions\n- **FIN7**: Adapting techniques for cloud environments\n\n**Recommendation**: Prioritize Linux system patching and enhance supply chain security monitoring."
            },
            'generate executive summary of security posture': {
                response: "**Executive Security Posture Summary**\n\n**Overall Risk Level: MEDIUM-HIGH** ⚠️\n\n**Key Metrics:**\n- Total Systems Monitored: 2,847\n- Critical Vulnerabilities: 24 (immediate action required)\n- High-Risk Vulnerabilities: 156\n- Security Controls Effectiveness: 78%\n\n**Top Risks:**\n1. **Unpatched Linux systems** - Critical exposure\n2. **Web server vulnerabilities** - Active exploitation risk\n3. **Legacy system dependencies** - Limited patch availability\n\n**Recommendations:**\n1. Emergency patching for CVE-2024-1086 within 24 hours\n2. Implement additional monitoring for privilege escalation\n3. Review and update incident response procedures\n\n**Business Impact:**\n- **Low**: System availability maintained\n- **Medium**: Potential data exposure risk\n- **High**: Compliance and reputation concerns\n\nDetailed technical report available upon request."
            }
        };
        
        // Check for exact matches first
        for (const [key, data] of Object.entries(sampleResponses)) {
            if (lowerQuery === key.toLowerCase()) {
                return data.response;
            }
        }
        
        // Pattern-based responses
        if (lowerQuery.includes('critical') && (lowerQuery.includes('vulnerabil') || lowerQuery.includes('threat'))) {
            const criticalCount = this.vulnerabilities.filter(v => v.severity === 'critical').length;
            const mostRecent = this.vulnerabilities.find(v => v.severity === 'critical');
            return `I've identified **${criticalCount} critical vulnerabilities** in your environment. The most concerning is ${mostRecent?.title || 'CVE-2024-1086'} with a CVSS score of ${mostRecent?.cvss || '9.8'}. This requires immediate attention as it allows privilege escalation.\n\n**Immediate Actions:**\n1. Isolate affected systems\n2. Apply emergency patches\n3. Monitor for exploitation attempts\n\nWould you like me to provide detailed mitigation steps?`;
        }
        
        if (lowerQuery.includes('cve-') || lowerQuery.includes('vulnerability')) {
            const cveMatch = lowerQuery.match(/cve-\d{4}-\d+/);
            if (cveMatch) {
                const cve = cveMatch[0].toUpperCase();
                const vuln = this.vulnerabilities.find(v => v.cve === cve);
                if (vuln) {
                    return `**${vuln.cve} Analysis:**\n\n**Severity:** ${vuln.severity.toUpperCase()} (CVSS ${vuln.cvss})\n**Title:** ${vuln.title}\n**Description:** ${vuln.description}\n\n**Affected Systems:** ${vuln.affected.join(', ')}\n**Discovery Date:** ${vuln.discovered.toLocaleDateString()}\n\n**Risk Assessment:** This vulnerability poses a ${vuln.severity} risk to your infrastructure. ${vuln.severity === 'critical' ? 'Immediate action required.' : 'Patch within standard maintenance window.'}\n\nWould you like specific remediation guidance?`;
                }
            }
            return "I can help you analyze specific vulnerabilities. Please provide a CVE ID or describe the vulnerability you'd like me to investigate. I have detailed information on the latest threats in our database.";
        }
        
        if (lowerQuery.includes('scan') && (lowerQuery.includes('status') || lowerQuery.includes('progress'))) {
            if (this.scanInProgress) {
                return `**MCP-Enhanced Scan Status:**\n\nCurrent scan is **${this.scanProgress.toFixed(1)}% complete** and in the **${this.scanPhase}** phase.\n\n**MCP Pipeline Activity:**\n- Target: ${document.getElementById('scan-target')?.value || 'Multiple targets'}\n- Threat Intelligence Correlation: Active\n- Vulnerability Enrichment: Running\n- Attack Path Analysis: In Progress\n- Elapsed Time: ${Math.floor(this.scanProgress * 0.25)} minutes\n- Estimated Completion: ${Math.ceil((100 - this.scanProgress) * 0.25)} minutes remaining\n\n**MCP Processing Rate:** 1.8k events/sec\n\nThe MCP pipeline is actively correlating scan results with threat intelligence to provide enhanced context and attack path analysis.`;
            } else {
                return "**MCP System Status:** All scanners and pipeline components are ready.\n\n**Available MCP-Enhanced Scan Types:**\n- Natural Language Query Processing (Recommended)\n- Network Discovery with Threat Correlation (5-10 minutes)\n- Comprehensive Vulnerability Assessment with MCP (30-60 minutes)\n- Stealth Scan with Intelligence Enrichment (15-30 minutes)\n\n**MCP Features:**\n✅ Automatic scanner selection based on queries\n✅ Real-time threat intelligence correlation\n✅ Advanced attack path visualization\n✅ AI-powered vulnerability prioritization\n\nTry the **Query Interface** tab for natural language security queries!";
            }
        }
        
        if (lowerQuery.includes('threat') && lowerQuery.includes('intelligence')) {
            const totalAlerts = this.threatFeeds.reduce((sum, feed) => sum + feed.alerts, 0);
            return `**Threat Intelligence Summary:**\n\n**Active Feeds:** ${this.threatFeeds.length} sources\n**New Alerts:** ${totalAlerts} in the last 24 hours\n\n**Top Threat Actors:**\n- **APT28:** Targeting infrastructure (12 campaigns)\n- **Lazarus Group:** Financial sector focus (8 campaigns)\n- **FIN7:** Cloud environment attacks (15 campaigns)\n\n**Trending Attack Vectors:**\n1. Linux kernel exploits (↑ 67%)\n2. Supply chain compromises (↑ 45%)\n3. Cloud misconfigurations (↑ 23%)\n\n**Recommendations:** Focus on Linux system hardening and supply chain security monitoring.`;
        }
        
        if (lowerQuery.includes('security posture') || lowerQuery.includes('risk assessment')) {
            const criticalCount = this.vulnerabilities.filter(v => v.severity === 'critical').length;
            const highCount = this.vulnerabilities.filter(v => v.severity === 'high').length;
            const totalSystems = 2847;
            
            return `**Security Posture Assessment:**\n\n**Risk Level:** ${criticalCount > 5 ? 'HIGH ⚠️' : criticalCount > 2 ? 'MEDIUM 📊' : 'LOW ✅'}\n\n**Vulnerability Breakdown:**\n- Critical: ${criticalCount} (immediate action required)\n- High: ${highCount} (patch within 72 hours)\n- Medium: ${this.vulnerabilities.filter(v => v.severity === 'medium').length}\n- Low: ${this.vulnerabilities.filter(v => v.severity === 'low').length}\n\n**System Coverage:** ${totalSystems.toLocaleString()} systems monitored\n**Compliance Status:** 78% of security controls effective\n\n**Priority Actions:**\n1. Address critical vulnerabilities immediately\n2. Strengthen privilege escalation monitoring\n3. Enhance threat detection capabilities`;
        }
        
        if (lowerQuery.includes('mitigation') || lowerQuery.includes('remediation')) {
            return "**Mitigation Strategy Framework:**\n\n**Immediate (0-24 hours):**\n1. Patch critical vulnerabilities\n2. Isolate compromised systems\n3. Enable enhanced monitoring\n\n**Short-term (1-7 days):**\n1. Deploy security updates\n2. Review access controls\n3. Validate backup systems\n\n**Long-term (1-4 weeks):**\n1. Security architecture review\n2. Penetration testing\n3. Staff training and awareness\n\nWhich specific vulnerability or threat would you like me to provide detailed mitigation steps for?";
        }
        
        if (lowerQuery.includes('attack path') || lowerQuery.includes('kill chain')) {
            return "**Attack Path Analysis:**\n\n**Common Attack Progression:**\n1. **Initial Access** → Phishing, exposed services\n2. **Execution** → Malware deployment, script execution\n3. **Persistence** → Registry modification, scheduled tasks\n4. **Privilege Escalation** → Kernel exploits, misconfigurations\n5. **Lateral Movement** → Network enumeration, credential theft\n6. **Collection** → Data harvesting, system reconnaissance\n7. **Exfiltration** → Data transfer, command & control\n\n**Current Threat Vectors:**\n- Linux kernel vulnerabilities (CVE-2024-1086)\n- Web application exploitation\n- Supply chain compromise\n\nWould you like me to analyze attack paths specific to your current vulnerabilities?";
        }
        
        // General responses
        if (lowerQuery.includes('help') || lowerQuery.includes('what can you do')) {
            return `**Hi! I'm ARIA, your Advanced Risk Intelligence Assistant.** 🤖\n\nI can help you with:\n\n🔍 **Vulnerability Analysis**\n- Detailed CVE explanations\n- Risk assessments and CVSS scoring\n- Impact analysis\n\n🛡️ **Threat Intelligence**\n- Current threat landscape\n- APT group activities\n- Attack pattern analysis\n\n📊 **Security Recommendations**\n- Mitigation strategies\n- Patch prioritization\n- Security architecture guidance\n\n📈 **Risk Assessment**\n- Security posture evaluation\n- Compliance gap analysis\n- Executive reporting\n\nTry asking me things like:\n- "Analyze critical vulnerabilities"\n- "What's the attack path for CVE-2024-1086?"\n- "Recommend mitigation strategies"\n- "Generate security posture summary"\n\nHow can I assist you today?`;
        }
        
        // Default intelligent response
        return `I understand you're asking about: **"${query}"**\n\nBased on your query, I can provide insights on vulnerability analysis, threat intelligence, or security recommendations. Here are some ways I can help:\n\n• **Vulnerability Details:** Provide CVSS scores, impact analysis, and affected systems\n• **Threat Context:** Correlate with current threat intelligence and APT activities\n• **Remediation Guidance:** Suggest specific mitigation strategies and patch priorities\n• **Risk Assessment:** Evaluate business impact and compliance implications\n\nCould you be more specific about what aspect you'd like me to focus on? For example:\n- "Analyze [specific CVE]"\n- "What are the current critical threats?"\n- "Recommend mitigation for [vulnerability type]"\n- "Assess risk for [system/application]"`;
    }
    
    exportConversation() {
        if (this.currentConversation.length === 0) {
            this.showNotification('No conversation to export', 'warning');
            return;
        }
        
        const timestamp = new Date().toISOString().split('T')[0];
        const conversationData = {
            export_date: new Date().toISOString(),
            bot_name: this.ragBot.name,
            session_id: `session_${Date.now()}`,
            messages: this.currentConversation.map(msg => ({
                sender: msg.sender,
                message: msg.message,
                timestamp: msg.timestamp.toISOString(),
                container: msg.container
            }))
        };
        
        const jsonData = JSON.stringify(conversationData, null, 2);
        const blob = new Blob([jsonData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ARIA_conversation_${timestamp}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.showNotification('Conversation exported successfully', 'success');
    }
    
    generateRagReport() {
        this.showNotification('Generating RAG intelligence report...', 'info');
        
        setTimeout(() => {
            const reportData = {
                title: 'ARIA Intelligence Report',
                generated: new Date().toISOString(),
                summary: {
                    total_queries: this.currentConversation.length,
                    critical_issues_discussed: this.vulnerabilities.filter(v => v.severity === 'critical').length,
                    recommendations_provided: Math.floor(this.currentConversation.length * 0.7),
                    risk_level: 'MEDIUM-HIGH'
                },
                key_insights: [
                    'CVE-2024-1086 requires immediate attention',
                    'Apache vulnerabilities actively exploited',
                    'Linux systems need priority patching',
                    'Enhanced monitoring recommended'
                ],
                conversation_summary: this.currentConversation.slice(-10)
            };
            
            const jsonData = JSON.stringify(reportData, null, 2);
            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ARIA_intelligence_report_${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            URL.revokeObjectURL(url);
            
            this.showNotification('RAG intelligence report generated successfully', 'success');
        }, 2000);
    }
    
    generateScanResults() {
        this.scanResults = {
            target: document.getElementById('scan-target')?.value || 'Unknown',
            timestamp: new Date(),
            vulnerabilities: [...this.vulnerabilities],
            summary: {
                critical: this.vulnerabilities.filter(v => v.severity === 'critical').length,
                high: this.vulnerabilities.filter(v => v.severity === 'high').length,
                medium: this.vulnerabilities.filter(v => v.severity === 'medium').length,
                low: this.vulnerabilities.filter(v => v.severity === 'low').length
            }
        };
    }
    
    generateMockResults() {
        this.scanResults = {
            target: 'Mock Scan Results',
            timestamp: new Date(),
            vulnerabilities: [...this.vulnerabilities],
            summary: {
                critical: this.vulnerabilities.filter(v => v.severity === 'critical').length,
                high: this.vulnerabilities.filter(v => v.severity === 'high').length,
                medium: this.vulnerabilities.filter(v => v.severity === 'medium').length,
                low: this.vulnerabilities.filter(v => v.severity === 'low').length
            }
        };
    }
    
    displayResults() {
        if (!this.scanResults) return;
        
        this.displayVulnerabilityList();
        this.displaySeverityChart();
        this.displayTrendsChart();
        this.displayAttackGraph();
    }
    
    displayVulnerabilityList() {
        const tableEl = document.getElementById('vulnerability-table');
        if (!tableEl) return;
        
        tableEl.innerHTML = this.vulnerabilities.map(vuln => `
            <div class="vuln-item">
                <div class="severity-badge severity-${vuln.severity}">
                    ${vuln.severity}
                </div>
                <div>
                    <div class="vuln-title">${vuln.title}</div>
                    <div class="vuln-cve">${vuln.cve}</div>
                    <div style="color: #8892b0; font-size: 13px; margin-top: 4px;">
                        ${vuln.description}
                    </div>
                </div>
                <div class="vuln-cvss">
                    <i class="fas fa-chart-line"></i>
                    ${vuln.cvss}
                </div>
                <div style="color: #8892b0; font-size: 12px;">
                    ${vuln.discovered.toLocaleDateString()}
                </div>
                <div>
                    <button class="report-btn" onclick="app.showVulnDetails('${vuln.cve}')">
                        <i class="fas fa-eye"></i> Details
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    displaySeverityChart() {
        const ctx = document.getElementById('severity-chart');
        if (!ctx) return;
        
        // Destroy existing chart
        if (this.charts.severity) {
            this.charts.severity.destroy();
        }
        
        const summary = this.scanResults.summary;
        
        this.charts.severity = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Critical', 'High', 'Medium', 'Low'],
                datasets: [{
                    data: [summary.critical, summary.high, summary.medium, summary.low],
                    backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#22c55e'],
                    borderWidth: 2,
                    borderColor: '#1a2038'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#e4e6ea',
                            padding: 20,
                            font: {
                                size: 14
                            }
                        }
                    }
                }
            }
        });
    }
    
    displayTrendsChart() {
        const ctx = document.getElementById('trends-chart');
        if (!ctx) return;
        
        // Destroy existing chart
        if (this.charts.trends) {
            this.charts.trends.destroy();
        }
        
        // Generate mock trend data
        const labels = [];
        const criticalData = [];
        const highData = [];
        const mediumData = [];
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }));
            
            criticalData.push(Math.floor(Math.random() * 10) + 15);
            highData.push(Math.floor(Math.random() * 20) + 30);
            mediumData.push(Math.floor(Math.random() * 30) + 20);
        }
        
        this.charts.trends = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [
                    {
                        label: 'Critical',
                        data: criticalData,
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'High',
                        data: highData,
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Medium',
                        data: mediumData,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#e4e6ea'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#8892b0' },
                        grid: { color: 'rgba(136, 146, 176, 0.1)' }
                    },
                    y: {
                        ticks: { color: '#8892b0' },
                        grid: { color: 'rgba(136, 146, 176, 0.1)' }
                    }
                }
            }
        });
    }
    
    displayAttackGraph() {
        const graphEl = document.getElementById('attack-graph');
        if (!graphEl) return;
        
        // Simple network diagram representation
        graphEl.innerHTML = `
            <div style="text-align: center; color: #8892b0;">
                <div style="margin-bottom: 20px;">
                    <i class="fas fa-globe" style="font-size: 32px; color: #64ffda;"></i>
                    <br>
                    <small>Internet</small>
                </div>
                <div style="margin: 20px 0;">
                    <i class="fas fa-arrow-down" style="color: #ef4444;"></i>
                    <br>
                    <small style="color: #ef4444;">Attack Vector</small>
                </div>
                <div style="display: flex; justify-content: space-around; align-items: center;">
                    <div>
                        <i class="fas fa-server" style="font-size: 24px; color: #f59e0b;"></i>
                        <br>
                        <small>Web Server</small>
                        <br>
                        <small style="color: #f59e0b;">Vulnerable</small>
                    </div>
                    <div>
                        <i class="fas fa-database" style="font-size: 24px; color: #ef4444;"></i>
                        <br>
                        <small>Database</small>
                        <br>
                        <small style="color: #ef4444;">High Risk</small>
                    </div>
                    <div>
                        <i class="fas fa-desktop" style="font-size: 24px; color: #22c55e;"></i>
                        <br>
                        <small>Workstations</small>
                        <br>
                        <small style="color: #22c55e;">Protected</small>
                    </div>
                </div>
                <div style="margin-top: 30px; font-size: 14px; color: #ccd6f6;">
                    <strong>Attack Path Analysis:</strong><br>
                    Internet → Web Server (CVE-2024-0519) → Database (Privilege Escalation)
                </div>
            </div>
        `;
    }
    
    filterVulnerabilities(severity) {
        const filtered = severity === 'all' ? this.vulnerabilities : this.vulnerabilities.filter(v => v.severity === severity);
        this.displayFilteredVulnerabilities(filtered);
    }
    
    searchVulnerabilities(query) {
        const filtered = this.vulnerabilities.filter(v => 
            v.title.toLowerCase().includes(query.toLowerCase()) ||
            v.cve.toLowerCase().includes(query.toLowerCase()) ||
            v.description.toLowerCase().includes(query.toLowerCase())
        );
        this.displayFilteredVulnerabilities(filtered);
    }
    
    displayFilteredVulnerabilities(vulnerabilities) {
        const tableEl = document.getElementById('vulnerability-table');
        if (!tableEl) return;
        
        tableEl.innerHTML = vulnerabilities.map(vuln => `
            <div class="vuln-item">
                <div class="severity-badge severity-${vuln.severity}">
                    ${vuln.severity}
                </div>
                <div>
                    <div class="vuln-title">${vuln.title}</div>
                    <div class="vuln-cve">${vuln.cve}</div>
                    <div style="color: #8892b0; font-size: 13px; margin-top: 4px;">
                        ${vuln.description}
                    </div>
                </div>
                <div class="vuln-cvss">
                    <i class="fas fa-chart-line"></i>
                    ${vuln.cvss}
                </div>
                <div style="color: #8892b0; font-size: 12px;">
                    ${vuln.discovered.toLocaleDateString()}
                </div>
                <div>
                    <button class="report-btn" onclick="app.showVulnDetails('${vuln.cve}')">
                        <i class="fas fa-eye"></i> Details
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    showVulnDetails(cve) {
        const vuln = this.vulnerabilities.find(v => v.cve === cve);
        if (!vuln) return;
        
        this.showNotification(`Vulnerability Details: ${vuln.title} (${vuln.cve})\nSeverity: ${vuln.severity.toUpperCase()}\nCVSS: ${vuln.cvss}\n\n${vuln.description}\n\nAffected: ${vuln.affected.join(', ')}`, 'info');
    }
    
    exportResults(format) {
        if (!this.scanResults) {
            this.showNotification('No scan results to export', 'warning');
            return;
        }
        
        this.showNotification(`Exporting results as ${format.toUpperCase()}...`, 'info');
        
        setTimeout(() => {
            if (format === 'pdf') {
                // Simulate PDF generation
                const blob = new Blob(['Mock PDF Report Content'], { type: 'application/pdf' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `vulnerability_report_${Date.now()}.pdf`;
                a.click();
                URL.revokeObjectURL(url);
            } else if (format === 'json') {
                // Generate JSON export
                const jsonData = JSON.stringify(this.scanResults, null, 2);
                const blob = new Blob([jsonData], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `vulnerability_report_${Date.now()}.json`;
                a.click();
                URL.revokeObjectURL(url);
            }
            
            this.showNotification(`${format.toUpperCase()} report exported successfully`, 'success');
        }, 1000);
    }
    
    generateReports() {
        const reportsEl = document.getElementById('reports-list');
        if (!reportsEl) return;
        
        const mockReports = [
            {
                title: 'Q4 2024 Security Assessment',
                date: '2024-10-10',
                type: 'Quarterly',
                vulnerabilities: 234,
                systems: 145,
                status: 'completed'
            },
            {
                title: 'Network Infrastructure Scan',
                date: '2024-10-08',
                type: 'Network',
                vulnerabilities: 67,
                systems: 89,
                status: 'completed'
            },
            {
                title: 'Web Application Security Review',
                date: '2024-10-05',
                type: 'Web App',
                vulnerabilities: 23,
                systems: 12,
                status: 'completed'
            },
            {
                title: 'Compliance Audit Report',
                date: '2024-09-30',
                type: 'Compliance',
                vulnerabilities: 156,
                systems: 203,
                status: 'completed'
            }
        ];
        
        reportsEl.innerHTML = mockReports.map(report => `
            <div class="report-card">
                <div class="report-header">
                    <div>
                        <div class="report-title">${report.title}</div>
                        <div class="report-date">${new Date(report.date).toLocaleDateString('en-IN')}</div>
                    </div>
                    <div class="report-type">${report.type}</div>
                </div>
                <div class="report-stats">
                    <span>${report.vulnerabilities} vulnerabilities</span>
                    <span>${report.systems} systems</span>
                </div>
                <div class="report-actions">
                    <a href="#" class="report-btn" onclick="app.downloadReport('${report.title}', 'pdf')">
                        <i class="fas fa-download"></i> PDF
                    </a>
                    <a href="#" class="report-btn" onclick="app.downloadReport('${report.title}', 'json')">
                        <i class="fas fa-code"></i> JSON
                    </a>
                    <a href="#" class="report-btn" onclick="app.viewReport('${report.title}')">
                        <i class="fas fa-eye"></i> View
                    </a>
                </div>
            </div>
        `).join('');
    }
    
    generateNewReport() {
        this.showNotification('Generating new security report...', 'info');
        
        setTimeout(() => {
            const newReport = {
                title: `Custom Security Report - ${new Date().toLocaleDateString('en-IN')}`,
                date: new Date().toISOString().split('T')[0],
                type: 'Custom',
                vulnerabilities: this.vulnerabilities.length,
                systems: 156,
                status: 'completed'
            };
            
            this.showNotification('New report generated successfully!', 'success');
            this.generateReports(); // Refresh reports list
        }, 2000);
    }
    
    downloadReport(title, format) {
        this.showNotification(`Downloading ${title} as ${format.toUpperCase()}...`, 'info');
        
        setTimeout(() => {
            const content = format === 'pdf' ? 'Mock PDF Content' : JSON.stringify({ title, generated: new Date() }, null, 2);
            const mimeType = format === 'pdf' ? 'application/pdf' : 'application/json';
            
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${title.replace(/\s+/g, '_')}.${format}`;
            a.click();
            URL.revokeObjectURL(url);
            
            this.showNotification(`${title} downloaded successfully`, 'success');
        }, 1000);
    }
    
    viewReport(title) {
        this.showNotification(`Opening ${title}...`, 'info');
        // In a real app, this would open a detailed report view
        setTimeout(() => {
            this.showNotification(`Report details for ${title} would be displayed here`, 'info');
        }, 500);
    }
    
    updateTimestamps() {
        const now = new Date();
        const timestamp = now.toLocaleString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            timeZone: 'Asia/Kolkata'
        });
        
        const timestampEl = document.getElementById('dashboard-timestamp');
        if (timestampEl) {
            timestampEl.textContent = timestamp;
        }
    }
    
    showNotification(message, type = 'info') {
        // Backward compatibility - use modern notification
        this.showModernNotification(message, type);
    }
    
    showModernNotification(message, type = 'info', title = null) {
        // Modern enterprise-style notification
        const notification = document.createElement('div');
        notification.className = `toast-notification ${type}`;
        
        const iconMap = {
            'success': 'fas fa-check',
            'error': 'fas fa-times',
            'warning': 'fas fa-exclamation-triangle',
            'info': 'fas fa-info-circle'
        };
        
        notification.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon ${type}">
                    <i class="${iconMap[type] || 'fas fa-info-circle'}"></i>
                </div>
                <div class="toast-message">
                    ${title ? `<div class="toast-title">${title}</div>` : ''}
                    ${message}
                </div>
                <button class="toast-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOutRight 0.3s ease-in';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }
        }, 5000);
    }
    
    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (!overlay) return;
        
        if (show) {
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }
}

// Add notification animations
const style = document.createElement('style');
style.textContent = `
@keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

@keyframes slideOutRight {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}
`;
document.head.appendChild(style);

// Initialize application
const app = new SecureIntelHub();

// Make app globally available for onclick handlers
window.app = app;

// Add keyboard shortcuts for RAG bot
document.addEventListener('keydown', (e) => {
    // Ctrl+K or Cmd+K to open RAG chat
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (!app.chatWidgetVisible) {
            app.toggleChatWidget();
        }
        document.getElementById('chat-input')?.focus();
    }
    
    // Escape to close chat widget
    if (e.key === 'Escape' && app.chatWidgetVisible) {
        app.toggleChatWidget();
    }
});

// Auto-focus chat input when widget opens
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            const widget = document.getElementById('rag-chat-widget');
            if (widget && !widget.classList.contains('hidden')) {
                setTimeout(() => {
                    document.getElementById('chat-input')?.focus();
                }, 100);
            }
        }
    });
});

const widget = document.getElementById('rag-chat-widget');
if (widget) {
    observer.observe(widget, { attributes: true });
}